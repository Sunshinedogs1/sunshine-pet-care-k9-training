# Sunshine Pet Care & K9 Training — Starter Site

This is a colorful, family-friendly starter website tailored for a balanced dog training business. It includes:

- **Scheduling** via Calendly embed
- **Training videos** via YouTube playlist embed
- **Shop** via Ecwid free store embed (up to 5 products on the free plan)
- **Animated progress tracker** with virtual rewards (localStorage)
- Cartoon logo and playful design

## 1) Edit your embeds

- **Calendly**: Replace `YOUR_LINK` in `index.html` with your real Calendly scheduling URL.
- **YouTube**: Replace `PLAYLIST_ID` in `script.js` with your playlist ID (e.g., `PL...`).
- **Ecwid**: Replace `STORE_ID` in `script.js` with your Ecwid store ID. Then add products in Ecwid.

## 2) Publish free on GitHub Pages

1. Create a free GitHub account.
2. Make a new repository named `sunshine-pet-care-k9-training`.
3. Upload all files from this folder.
4. In repository settings → **Pages** → choose `main` branch `/root` and save. Your site will be live at:
   `https://YOURUSERNAME.github.io/sunshine-pet-care-k9-training/`

## 3) Connect your `.com` domain

Domains are not free. Purchase `sunshinepetcareandk9training.com` (or similar) at a registrar (≈ $10–$15/year). In DNS, set:

- `CNAME` for `www` → `YOURUSERNAME.github.io`
- Optional root domain A records → GitHub Pages IPs (check GitHub docs)

Then in GitHub Pages → **Custom domain**, enter your domain and enforce HTTPS.

## 4) Make edits easily

- Update content in `index.html` (headings, class descriptions, contact info).
- Colors and font in `style.css`.
- Interactions (progress, rewards, embeds) in `script.js`.

## 5) Optional upgrades

- **Client logins & synced progress**: Use services like Firebase Auth + Firestore or Notion forms + Make/Zapier to sync milestones.
- **Bookings**: Calendly free works; paid tiers unlock reminders and more.
- **Store**: Ecwid paid tiers allow more products, discounts, etc.

## 6) Accessibility & performance

- Alt text provided; keep contrast strong.
- Images should be optimized (SVG used for logo).

Enjoy building!