// Sunshine Pet Care & K9 Training - Interactivity
const state = {
  progress: 0,         // percent
  level: 1,            // 1..5
  rewards: []          // strings
};

function loadState(){
  try {
    const saved = JSON.parse(localStorage.getItem('sunshineProgress'));
    if(saved){ Object.assign(state, saved); }
  } catch(e){ console.warn('No saved state'); }
}

function saveState(){
  localStorage.setItem('sunshineProgress', JSON.stringify(state));
}

function updateUI(){
  document.querySelector('.progress-fill').style.width = state.progress + '%';
  document.querySelectorAll('.level').forEach((el, idx)=>{
    const levelNum = idx+1;
    el.classList.toggle('unlocked', levelNum <= state.level);
  });
  const rewardList = document.getElementById('reward-list');
  rewardList.innerHTML = '';
  state.rewards.forEach(r=>{
    const li = document.createElement('li');
    li.textContent = r;
    rewardList.appendChild(li);
  });
}

function award(type){
  const map = {
    trophy: '🏆 Trophy earned! Obedience level completed.',
    ribbon: '🎗️ Ribbon earned! Manners milestone achieved.',
    medal: '🥇 Medal earned! Trick class certified.'
  };
  const msg = map[type] || '⭐ Milestone achieved!';
  state.rewards.push(msg);
  toast(msg);
  saveState();
  updateUI();
}

function toast(msg){
  const t = document.createElement('div');
  t.className = 'toast';
  t.textContent = msg;
  Object.assign(t.style, {
    position:'fixed', bottom:'20px', left:'50%', transform:'translateX(-50%)',
    background:'#1B9AAA', color:'#fff', padding:'10px 16px', borderRadius:'999px',
    boxShadow:'0 8px 18px rgba(0,0,0,.2)', zIndex:9999, fontWeight:'800'
  });
  document.body.appendChild(t);
  setTimeout(()=> t.remove(), 3000);
}

function incrementProgress(amount){
  state.progress = Math.min(100, state.progress + amount);
  const newLevel = Math.min(5, Math.floor(state.progress/20) + 1);
  if(newLevel > state.level){
    state.level = newLevel;
    award('trophy');
  }
  saveState();
  updateUI();
}

// Demo buttons
function bindDemo(){
  document.getElementById('btn-progress').addEventListener('click', ()=> incrementProgress(10));
  document.getElementById('btn-ribbon').addEventListener('click', ()=> award('ribbon'));
  document.getElementById('btn-medal').addEventListener('click', ()=> award('medal'));
}

// Calendly embed init (replace with your actual link)
function initCalendly(){
  const script = document.createElement('script');
  script.src = 'https://assets.calendly.com/assets/external/widget.js';
  script.async = true;
  document.body.appendChild(script);
}

// Ecwid store embed (free plan supports up to 5 products). Replace STORE_ID.
function initStore(){
  const s1 = document.createElement('script');
  s1.src = 'https://app.ecwid.com/script.js?STORE_ID&data_platform=code&data_date=' + Date.now();
  s1.async = true;
  document.body.appendChild(s1);
  s1.onload = () => {
    if(window.xProductBrowser){
      window.xProductBrowser('categoriesPerRow=3','views=grid','categoryView=grid','searchView=list','id=my-store');
    }
  };
}

// YouTube playlist embed: replace PLAYLIST_ID
function initYouTube(){
  const iframe = document.getElementById('yt-playlist');
  iframe.src = 'https://www.youtube.com/embed/videoseries?list=PLAYLIST_ID';
}

// On load
window.addEventListener('DOMContentLoaded', ()=>{
  loadState();
  updateUI();
  bindDemo();
  initCalendly();
  initStore();
  initYouTube();
});
